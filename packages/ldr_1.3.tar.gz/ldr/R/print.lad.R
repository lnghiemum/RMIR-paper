print.lad <-
function(x,...){print(names(x))}
