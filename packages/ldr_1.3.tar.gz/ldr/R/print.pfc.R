print.pfc <-
function(x,...)
{
print(names(x))

}
