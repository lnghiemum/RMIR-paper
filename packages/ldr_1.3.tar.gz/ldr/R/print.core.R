print.core <-
function(x,...){print(names(x))}
